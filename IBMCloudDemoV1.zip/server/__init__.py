import os, sys
from flask import Flask, abort, session, request, redirect
from flask.json import jsonify
from ibmcloudenv import IBMCloudEnv

from flask import render_template
from twython import Twython
from ibm_watson import ApiException
from watson_developer_cloud import NaturalLanguageUnderstandingV1
from watson_developer_cloud.natural_language_understanding_v1 import Features, SentimentOptions
import twitter_psa_credentials as tc

app = Flask(__name__, template_folder="../public", static_folder="../public", static_url_path='')

from server.routes import *
from server.services import *

 
import logging
from logging.handlers import RotatingFileHandler
file_handler = RotatingFileHandler('python.log', maxBytes=1024 * 1024 * 100, backupCount=20)
file_handler.setLevel(logging.DEBUG)
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
file_handler.setFormatter(formatter)
app.logger.addHandler(file_handler)

initServices(app)

app.logger.debug("Started running....")
print("Started running....")

if 'FLASK_LIVE_RELOAD' in os.environ and os.environ['FLASK_LIVE_RELOAD'] == 'true':
	import livereload
	app.debug = True
	server = livereload.Server(app.wsgi_app)
	server.serve(port=os.environ['port'], host=os.environ['host'])

natural_language_understanding = NaturalLanguageUnderstandingV1(
    version='2018-11-16',
    iam_apikey=IBMCloudEnv.getString('watson_natural_language_understanding_apikey'),
    url=IBMCloudEnv.getString('watson_natural_language_understanding_url')
)

@app.route("/")
def index():
	return render_template('home.html')

@app.route("/search/", methods=['POST'])
def search():
	search_string = request.form['search_string']
	py_tweets = Twython(tc.ckey, tc.csecret)
	print("Inside Search...")
	query = {
		'q': search_string,
		'count': 10,
		'lang': 'en',
	}
	tweets = {
		'user': [],
		'date': [],
		'text': [],
		'url': [],
		'score': [],
		'label': [],
		'flag': [],
	}

	for status in py_tweets.search(**query)['statuses']:
		tweets['user'].append(status['user']['screen_name'])
		tweets['date'].append(status['created_at'])
		tweets['text'].append(status['text'])
		url_obj = status['entities']['urls']
		print(status)
		app.logger.debug(status)
		if len(url_obj) == 0:
			flag = False
			tweets['flag'].append(flag)
			tweets['url'].append(status['text'])
			try:
				response = natural_language_understanding.analyze(
	    			text = status['text'],
	    			features = Features(sentiment=SentimentOptions()),
	    			language='en').get_result()

			except ApiException as ex:
				print("Method failed with status code ", str(ex.code), ": ", ex.message)
			app.logger.debug("Done with this tweet: ", response)
			app.logger.debug("***********************************************")
			print("Done with this tweet: ", response)
			print("***********************************************")
			tweets['score'].append(response['sentiment']['document']['score'])
			tweets['label'].append(response['sentiment']['document']['label'])
		
		else:
			flag = True
			tweets['flag'].append(flag)

			url = url_obj[0]['url']
			tweets['url'].append(url)

			try:
				response = natural_language_understanding.analyze(
		    		text = status['text'],
		    		features = Features(sentiment=SentimentOptions()),
		    		language='en').get_result()

			except ApiException as ex:
				print("Methos failed with status code ", str(ex.code), ": ", ex.message)
				app.logger.info("Exception: ", ex.message)
			app.logger.debug("Done with this tweet: ", response)
			app.logger.debug("***********************************************")
			print("Done with this tweet: ", response)
			print("***********************************************")
			tweets['score'].append(response['sentiment']['document']['score'])
			tweets['label'].append(response['sentiment']['document']['label'])

	return render_template('data_display.html', data = tweets)

if __name__ == "__main__":
	app.run(debug=True)